 (function() {
     
     var youTubeWidth = window.innerWidth - 560;
     var youTubeHeight = window.innerHeight - 377;
     var wikiWidth = window.innerWidth - 460;
     var wikiHeight = window.innerHeight - 377;
  
  var tapHandler = function(button, event) { var txt = "User tapped the '" + button.text + "' button."; Ext.getCmp('GrandStaff').body.dom.innerHTML = txt; };
  
  
  var onContact = function(button, event) {
  
   PhoneGap.exec("ChildBrowserCommand.showWebPage", "http://randymcmillan.net/contactme" );
  
  };
  
  var onYouTube = function(button, event) {
  if (!Ext.is.Desktop) {
  
  
  PhoneGap.exec("ChildBrowserCommand.showWebPage", "http://www.youtube.com/watch?v=obx2VOtx0qU&key=AI39si5uWLRT16JtcIQCTvmSvpUmTzJxqCsceL6s4_LQj0FsJXSydWB0ccFWz7fddh5hJuF3zUcI7F_gu27ds9HHoisswEKuQA" );
  
  
  }
  
  else {
  
  
  if (!this.popup) {
  this.popup = null;
  this.popup = new Ext.Panel({
                             floating: true,
                             modal: true,
                             centered: true,
                             width: window.innerWidth - 560,
                             height: window.innerHeight - 380,
                             styleHtmlContent: true,
                             html: '<p><object width=" ' + youTubeWidth + ' " height=" ' + youTubeHeight + ' "><param name="movie" value="https://www.youtube.com/v/obx2VOtx0qU?version=3&amp;hl=en_US&amp;rel=0"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="https://www.youtube.com/v/obx2VOtx0qU?version=3&amp;hl=en_US&amp;rel=0&autoplay=1&hd=1%loop=1&autohide=1&key=AI39si5uWLRT16JtcIQCTvmSvpUmTzJxqCsceL6s4_LQj0FsJXSydWB0ccFWz7fddh5hJuF3zUcI7F_gu27ds9HHoisswEKuQA" type="application/x-shockwave-flash" width="425" height="349" allowscriptaccess="never" allowfullscreen="true"></embed></object></p>',
                             //dockedItems: [{
                             //            dock: 'top',
                             //          xtype: 'toolbar',
                             //        title: 'Overlay Title'
                             //      }],
                             scroll: 'vertical'
                             });
  }
  this.popup.show('pop');  
  }
};
  
  var onWiki = function(button, event) {
         if (!Ext.is.Desktop) {
             
             
             PhoneGap.exec("ChildBrowserCommand.showWebPage", "http://en.m.wikipedia.org/wiki?search=Grand+Staff" );
             
             
         }
         
         else {
             
             
             if (!this.popup) {
                 this.popup = null;
                 this.popup = new Ext.Panel({
                     floating: true,
                     modal: true,
                     centered: true,
                     width: window.innerWidth - 425,
                     height: window.innerHeight - 340,
                     id:'Wiki',
                     styleHtmlContent: true,
                     html: '<p><iframe frameborder="0" overflow:auto SRC="http://en.m.wikipedia.org/wiki?search=Grand+Staff" width=" ' + wikiWidth + ' " height=" ' + wikiHeight + ' "></iframe></p>',
                     //dockedItems: [{
                     //            dock: 'top',
                     //          xtype: 'toolbar',
                     //        title: 'Overlay Title'
                     //      }],
                     //scroll: 'vertical'
                 });
             }
             this.popup.show('pop');  
         }
     };
  
  var onSolfege = function(button, event) {
    if (!Ext.is.Tablet) {
    if (!this.popup) {
    this.popup = new Ext.Panel({
                             floating: true,
                             modal: true,
                             centered: true,
                             width: 350,
                             styleHtmlContent: true,
                             html: '<p><center><span class="do">Do</span><span class="dot">•</span><span class="di">Di</span><span class="dot">•</span> <span class="re">Re</span><span class="dot">•</span> <span class="ri">Ri</span><span class="dot">•</span> <span class="mi">Mi</span><span class="dot">•</span> <span class="fa">Fa</span><span class="dot">•</span> <span class="fi">Fi</span><span class="dot">•</span> <span class="sol">Sol</span><span class="dot">•</span> <span class="si">Si</span><span class="dot">•</span> <span class="la">La</span><span class="dot">•</span> <span class="li">Li</span><span class="dot">•</span> <span class="ti">Ti</span><span class="dot">•</span> <span class="do">Do</span></center></p><center>Practice visualizing each color while singing each tone.</center>',
                             //dockedItems: [{
                             //            dock: 'top',
                             //          xtype: 'toolbar',
                             //        title: 'Overlay Title'
                             //      }],
                             scroll: 'vertical'
                             });
  }
  this.popup.show('pop');
  } 
  else  
  { 
  if (!this.popup) {
  this.popup = new Ext.Panel({
                             floating: true,
                             modal: true,
                             centered: true,
                             width: 550,
                             styleHtmlContent: true,
                             html: '<p><center><span class="do">Do</span><span class="dot">•</span> <span class="di">Di</span><span class="dot">•</span> <span class="re">Re</span><span class="dot">•</span> <span class="ri">Ri</span><span class="dot">•</span> <span class="mi">Mi</span><span class="dot">•</span> <span class="fa">Fa</span><span class="dot">•</span> <span class="fi">Fi</span><span class="dot">•</span> <span class="sol">Sol</span><span class="dot">•</span> <span class="si">Si</span><span class="dot">•</span> <span class="la">La</span><span class="dot">•</span> <span class="li">Li</span><span class="dot">•</span> <span class="ti">Ti</span><span class="dot">•</span> <span class="do">Do</span></center></p><center>Practice visualizing each color while singing each tone.</center>',
                             //dockedItems: [{
                             //            dock: 'top',
                             //          xtype: 'toolbar',
                             //        title: 'Overlay Title'
                             //      }],
                             scroll: 'vertical'
                             });
  }
  this.popup.show('pop');
  }
};
  
  var onInteractive = function(button, event) {
         if (!Ext.is.Desktop) {
             
             
             PhoneGap.exec("ChildBrowserCommand.showWebPage", "http://www.musictheory.net" );
             
             
         }
         
         else {
             
             
             if (!this.popup) {
                 this.popup = null;
                 this.popup = new Ext.Panel({
                     floating: true,
                     modal: true,
                     centered: true,
                     width: 768,
                     height: 560,
                     id:'Interactive',
                     styleHtmlContent: true,
                     html: '<p><iframe frameborder="1" SRC="http://www.musictheory.net/calculators/accidental"  width="730" height="530"></iframe></p>',
                     //dockedItems: [{
                     //            dock: 'top',
                     //          xtype: 'toolbar',
                     //        title: 'Overlay Title'
                     //      }],
                     //scroll: 'vertical'
                 });
             }
             this.popup.show('pop');  
         }
     };
  
  
  var buttonsGroup1 = [{
                       text: 'Contact',
                       ui: 'action',
                       handler: onContact
                       }, {
                       text: 'Default',
                       hidden: true,
                       badgeText: '2',
                       handler: tapHandler
                       }, {
                       text: 'Round',
                       hidden: true,
                       ui: 'round',
                       handler: tapHandler
                       }];
  
  var buttonsGroup2 = [{
                       xtype: 'segmentedbutton',
                       allowDepress: true,
                       items: [{
                               text: 'YouTube',
                               handler: onYouTube
                               }, {
                               text: 'Wiki',
                               handler: onWiki
                               }, {
                               text: 'Solfege',
                               handler: onSolfege
                               },
                               {
                               text: 'Interactive',
                               handler: onInteractive
                               }]
                       }];
  
  var buttonsGroup3 = [{
                       text: 'Action',
                       hidden: true,
                       ui: 'action',
                       handler: tapHandler
                       }, {
                       text: 'Forward',
                       hidden: true,
                       ui: 'forward',
                       handler: tapHandler
                       }];
  
  if (!Ext.is.Phone) {
  buttonsGroup1.push({xtype: 'spacer'});
  buttonsGroup2.push({xtype: 'spacer'});
  
  var dockedItems = [new Ext.Toolbar({
                                     ui: 'light',
                                     dock: 'bottom',
                                     items: buttonsGroup1.concat(buttonsGroup2).concat(buttonsGroup3)
                                     })];
  }
  else {
  
  var dockedItems = [new Ext.Toolbar({
                                     ui: 'light',
                                     dock: 'bottom',
                                     items: buttonsGroup1.concat(buttonsGroup2).concat(buttonsGroup3)
                                     })];/* var dockedItems = [{
                     xtype: 'toolbar',
                     ui: 'light',
                     items: buttonsGroup1,
                     dock: 'bottom'
                     }, {
                     xtype: 'toolbar',
                     ui: 'dark',
                     items: buttonsGroup2,
                     dock: 'bottom'
                     }, {
                     xtype: 'toolbar',
                     ui: 'light',
                     items: buttonsGroup3,
                     dock: 'bottom'
                     }];
   */
  }
  
  demos.GrandStaff = new Ext.Panel({
                                 id: 'GrandStaff',
                                 cls: 'card card1',
                                 html: '<p><img class="solfege" src="resources/scaleSVGs/TrebleClef.svg" left="0" top="0"/><img class="solfege" src="resources/scaleSVGs/BassClef.svg" left="0" top="0"/></p>',
                                 dockedItems: dockedItems
                                 });
  })();
