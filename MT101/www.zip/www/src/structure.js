sink.Structure =
[

{
	text: 'Staff / Stave',
	cls: 'launchscreen',
	card: demos.Staff,
	items: [
	{
		text: 'GrandStaff',
		card: demos.GrandStaff,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Treble Clef',
		card: demos.TrebleClef,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Bass Clef',
		card: demos.BassClef,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Baritone Clef',
		card: demos.BariToneClef,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'SubBass Clef',
		card: demos.SubBassClef,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	]
},
{
	text: 'Scales',
	cls: 'launchscreen',
	items: [
	{
		text: 'GrandStaff',
		card: demos.GrandStaff,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Treble Clef',
		card: demos.TrebleClef,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Bass Clef',
		card: demos.BassClef,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	]
},
{
	text: 'Modes',
	cls: 'launchscreen',
	items: [
	{
		text: 'Ionian',
		card: demos.Ionian,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Dorian',
		card: demos.Dorian,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Phrygian',
		card: demos.Phrygian,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Lydian',
		card: demos.Lydian,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'MixoLydian',
		card: demos.MixoLydian,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Aeolian',
		card: demos.Aeolian,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Locrian',
		card: demos.Locrian,
		cardSwitchAnimation: 'fade',
		leaf: true
	},

	]
},
{
	text: 'Circle Of Fifths',
	cls: 'launchscreen',
	items: [
	{
		text: 'Circle Of Fifths',
		card: demos.CircleOfFifths,
		cardSwitchAnimation: 'fade',
		leaf: true
	},
	{
		text: 'Chromatic Circle',
		card: demos.ChromaticCircle,
		cardSwitchAnimation: 'fade',
		leaf: true
	}
	]
},

];

if (Ext.is.iOS || Ext.is.Desktop)
{
	sink.Structure.push({
		text: 'Simulator',
		leaf: true,
		card: demos.Simulator,
		source: 'src/demos/simulator.js'
	});
}

Ext.regModel('Demo', { fields: [
	{
		name: 'text',
		type: 'string'
	},

	{
		name: 'source',
		type: 'string'
	},

	{
		name: 'preventHide',
		type: 'boolean'
	},

	{
		name: 'cardSwitchAnimation'
	},

	{
		name: 'card'
	}
]
});

sink.StructureStore = new Ext.data.TreeStore({
	model: 'Demo',
	root: {
		items: sink.Structure
	},
	proxy: {
		type: 'ajax',
		reader: {
			type: 'tree',
			root: 'items'
		}
	}
});
