demos.Map = new Ext.Panel({
    layout: 'fit',
    items: [{
        xtype: 'map'
    }]
});