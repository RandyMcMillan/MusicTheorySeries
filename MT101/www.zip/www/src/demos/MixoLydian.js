(function() {

var onYouTube = function(button, event)
{
if (!Ext.is.Desktop)
	{
		var loc = "local.MixoLydian.html";
	Cordova.exec("MediaBrowserCommand.showWebPage", loc );
	}
};///end onYouTube

var onWiki = function(button, event)
{
if (!Ext.is.Desktop)
	{
		var loc = "http://en.m.wikipedia.org/wiki/Mixolydian_mode";
	Cordova.exec("ChildBrowserCommand.showWebPage", loc );
	}
};///end onYouTube



var buttonsGroup1 = [

{
	xtype: 'spacer'
},

{
	text: 'YouTube',
	hidden: !navigator.onLine,
	handler: onYouTube,
},
{
	text: 'Wikipedia',
	hidden: !navigator.onLine,
	handler: onWiki,
},
{
	text: 'Load using AJAX',
	hidden: true,
	handler: function()
	{
		var panel = example;
		panel.update('');
		panel.setLoading(true, true);
		
		Ext.Ajax.request({
			url: 'https://raw.github.com/RandyMcMillan/SenchaTouch/master/www/resources/apihtml/Accelerometer.html',
			success: function(response, opts)
				{
				panel.update(Ext.htmlDecode('<div class="ux-code" style="background-color:#eaeaea;width:98%; margin:0.1%; padding:1%">' + response.responseText + '</div>'));
				console.log (response.responseText);//view response.responseText in console
				panel.scroller.scrollTo({x: 0, y: 0});
				panel.setLoading(false);
				}///end sucess function
						});///end Ext.Ajax.request
}///end button handler
},
{
	xtype: 'spacer'
}///end AJAX item
];

var PGvideoBase = {
	url: 'resources/video/PhoneGapIntro.mov',
	//posterUrl: 'resources/video/PhoneGapIntro.png',
	loop: false,
	}

var PGautoVideo = new Ext.Video(Ext.apply({}, PGvideoBase, {
title: 'Video',
autoResume: true,
controls: true,
}
)
);

var dockedItems = [
	new Ext.Toolbar({
	ui: 'dark',
	dock: 'bottom',
	items: buttonsGroup1,
	//hidden: !Ext.is.iOS,
	})
	];


var example = new Ext.Panel({
	title:'Example',
	scroll:'none',
	styleHtmlContent: true,
	items: [
	{
		html:'<center><img class="GrandStaff" src="resources/scaleSVGs/MixoLydian.svg"></img></center>'
	}
	],
	dockedItems: dockedItems,
	});
	
/*
if (!Ext.is.Tablet)
{
	demos.GrandStaff = new Ext.TabPanel({
	cardSwitchAnimation: {
		type: 'pop',
		duration: 600
		},
	items: [example, PGautoVideo],
	})
}
else
{
*/
	demos.MixoLydian = example;/*Since 'example' is a panel it can be uses as the demos.ApplicationTarget */
/*
}
*/
})(); //End enclosed in function