//
//  iScrollLib.h
//  mb3
//
//  Created by Randy McMillan on 3/17/12.
//  Copyright (c) 2012 OpenOSX.org. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface iScrollLib : NSObject {}

extern NSString * const kISCROLL_LIB;

@end
