Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by atonia ( http://www.freesound.org/people/atonia/  )
You can find this pack online at: http://www.freesound.org/people/atonia/packs/7293/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 144843__atonia__82.wav
    * url: http://www.freesound.org/people/atonia/sounds/144843/
    * license: Creative Commons 0
  * 116384__atonia__89.wav
    * url: http://www.freesound.org/people/atonia/sounds/116384/
    * license: Creative Commons 0
  * 116383__atonia__88.wav
    * url: http://www.freesound.org/people/atonia/sounds/116383/
    * license: Creative Commons 0
  * 116382__atonia__87.wav
    * url: http://www.freesound.org/people/atonia/sounds/116382/
    * license: Creative Commons 0
  * 116381__atonia__86.wav
    * url: http://www.freesound.org/people/atonia/sounds/116381/
    * license: Creative Commons 0
  * 116380__atonia__85.wav
    * url: http://www.freesound.org/people/atonia/sounds/116380/
    * license: Creative Commons 0
  * 116379__atonia__84.wav
    * url: http://www.freesound.org/people/atonia/sounds/116379/
    * license: Creative Commons 0
  * 116378__atonia__83.wav
    * url: http://www.freesound.org/people/atonia/sounds/116378/
    * license: Creative Commons 0
  * 116376__atonia__81.wav
    * url: http://www.freesound.org/people/atonia/sounds/116376/
    * license: Creative Commons 0
  * 116375__atonia__80.wav
    * url: http://www.freesound.org/people/atonia/sounds/116375/
    * license: Creative Commons 0
  * 116374__atonia__79.wav
    * url: http://www.freesound.org/people/atonia/sounds/116374/
    * license: Creative Commons 0
  * 116373__atonia__78.wav
    * url: http://www.freesound.org/people/atonia/sounds/116373/
    * license: Creative Commons 0
  * 116372__atonia__77.wav
    * url: http://www.freesound.org/people/atonia/sounds/116372/
    * license: Creative Commons 0
  * 116371__atonia__76.wav
    * url: http://www.freesound.org/people/atonia/sounds/116371/
    * license: Creative Commons 0
  * 116370__atonia__75.wav
    * url: http://www.freesound.org/people/atonia/sounds/116370/
    * license: Creative Commons 0
  * 116369__atonia__74.wav
    * url: http://www.freesound.org/people/atonia/sounds/116369/
    * license: Creative Commons 0
  * 116368__atonia__73.wav
    * url: http://www.freesound.org/people/atonia/sounds/116368/
    * license: Creative Commons 0
  * 116367__atonia__72.wav
    * url: http://www.freesound.org/people/atonia/sounds/116367/
    * license: Creative Commons 0
  * 116366__atonia__71.wav
    * url: http://www.freesound.org/people/atonia/sounds/116366/
    * license: Creative Commons 0
  * 116365__atonia__70.wav
    * url: http://www.freesound.org/people/atonia/sounds/116365/
    * license: Creative Commons 0
  * 116364__atonia__69.wav
    * url: http://www.freesound.org/people/atonia/sounds/116364/
    * license: Creative Commons 0
  * 116363__atonia__68.wav
    * url: http://www.freesound.org/people/atonia/sounds/116363/
    * license: Creative Commons 0
  * 116362__atonia__67.wav
    * url: http://www.freesound.org/people/atonia/sounds/116362/
    * license: Creative Commons 0
  * 116361__atonia__66.wav
    * url: http://www.freesound.org/people/atonia/sounds/116361/
    * license: Creative Commons 0
  * 116360__atonia__65.wav
    * url: http://www.freesound.org/people/atonia/sounds/116360/
    * license: Creative Commons 0
  * 116359__atonia__64.wav
    * url: http://www.freesound.org/people/atonia/sounds/116359/
    * license: Creative Commons 0
  * 116358__atonia__63.wav
    * url: http://www.freesound.org/people/atonia/sounds/116358/
    * license: Creative Commons 0
  * 116357__atonia__62.wav
    * url: http://www.freesound.org/people/atonia/sounds/116357/
    * license: Creative Commons 0
  * 116356__atonia__61.wav
    * url: http://www.freesound.org/people/atonia/sounds/116356/
    * license: Creative Commons 0
  * 116355__atonia__60.wav
    * url: http://www.freesound.org/people/atonia/sounds/116355/
    * license: Creative Commons 0
  * 116354__atonia__59.wav
    * url: http://www.freesound.org/people/atonia/sounds/116354/
    * license: Creative Commons 0
  * 116353__atonia__58.wav
    * url: http://www.freesound.org/people/atonia/sounds/116353/
    * license: Creative Commons 0
  * 116352__atonia__57.wav
    * url: http://www.freesound.org/people/atonia/sounds/116352/
    * license: Creative Commons 0
  * 116351__atonia__56.wav
    * url: http://www.freesound.org/people/atonia/sounds/116351/
    * license: Creative Commons 0
  * 116350__atonia__55.wav
    * url: http://www.freesound.org/people/atonia/sounds/116350/
    * license: Creative Commons 0
  * 116349__atonia__54.wav
    * url: http://www.freesound.org/people/atonia/sounds/116349/
    * license: Creative Commons 0
  * 116348__atonia__53.wav
    * url: http://www.freesound.org/people/atonia/sounds/116348/
    * license: Creative Commons 0

